package com.sellebro.access;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;

public class MainActivity extends Activity {
    // Demo-only local key. This does not modify or unlock another app.
    private static final String ACCESS_KEY = "@Sellebro";
    private LinearLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showLogin();
    }

    private void setupRoot() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(Color.rgb(16, 22, 35));
        setContentView(root);
    }

    private TextView text(String value, int size) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setPadding(8, 12, 8, 12);
        return v;
    }

    private void showLogin() {
        setupRoot();
        TextView title = text("SELLEBRO ACCESS", 26);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        root.addView(text("Введите ключ доступа", 16));

        EditText keyInput = new EditText(this);
        keyInput.setSingleLine(true);
        keyInput.setHint("Ключ");
        keyInput.setTextColor(Color.WHITE);
        keyInput.setHintTextColor(Color.LTGRAY);
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT |
                InputType.TYPE_TEXT_VARIATION_PASSWORD);
        keyInput.setPadding(18, 12, 18, 12);
        root.addView(keyInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        Button enter = new Button(this);
        enter.setText("ВОЙТИ");
        root.addView(enter);
        enter.setOnClickListener(v -> {
            if (ACCESS_KEY.equals(keyInput.getText().toString().trim())) {
                showSuccess();
            } else {
                Toast.makeText(this, "Неверный ключ", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showSuccess() {
        setupRoot();
        TextView title = text("ДОСТУП ОТКРЫТ", 26);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);
        root.addView(text("Ключ @Sellebro принят", 17));

        Button logout = new Button(this);
        logout.setText("ВЫЙТИ");
        root.addView(logout);
        logout.setOnClickListener(v -> showLogin());
    }
}
